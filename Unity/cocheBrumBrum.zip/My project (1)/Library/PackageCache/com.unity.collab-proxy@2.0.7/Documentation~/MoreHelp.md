# More help

To find more information on working with the Unity version control plug-in, see [Getting started with Unity Version control](https://docs.unity3d.com/2022.1/Documentation/Manual/PlasticSCMPluginGettingStarted.html).

You can also post and find questions related to Unity version control in the [Unity forum](https://forum.unity.com/forums/plastic-scm.605/).

